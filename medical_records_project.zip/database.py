
import sqlite3

def init_db():
    conn = sqlite3.connect('db.sqlite')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS match_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_name TEXT, age INTEGER, blood_type TEXT,
                        ward TEXT, donor_name TEXT, donor_blood_type TEXT,
                        recipient_name TEXT, notes TEXT)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS incoming_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_name TEXT, patient_blood_type TEXT,
                        donor_name TEXT, donor_blood_type TEXT)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS outgoing_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_name TEXT, patient_blood_type TEXT,
                        request_type TEXT, outgoing_serial TEXT)''')

    conn.commit()
    conn.close()

def insert_match(data):
    with sqlite3.connect('db.sqlite') as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO match_records
                          (patient_name, age, blood_type, ward, donor_name, donor_blood_type, recipient_name, notes)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                       (data['patient_name'], data['age'], data['blood_type'], data['ward'],
                        data['donor_name'], data['donor_blood_type'], data['recipient_name'], data['notes']))
        conn.commit()

def insert_incoming(data):
    with sqlite3.connect('db.sqlite') as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO incoming_records
                          (patient_name, patient_blood_type, donor_name, donor_blood_type)
                          VALUES (?, ?, ?, ?)''',
                       (data['patient_name'], data['patient_blood_type'], data['donor_name'], data['donor_blood_type']))
        conn.commit()

def insert_outgoing(data):
    with sqlite3.connect('db.sqlite') as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO outgoing_records
                          (patient_name, patient_blood_type, request_type, outgoing_serial)
                          VALUES (?, ?, ?, ?)''',
                       (data['patient_name'], data['patient_blood_type'], data['request_type'], data['outgoing_serial']))
        conn.commit()

def get_records(table):
    with sqlite3.connect('db.sqlite') as conn:
        cursor = conn.cursor()
        cursor.execute(f'SELECT * FROM {table}')
        return cursor.fetchall()
